Group 6

Ajinkya Padwad [aap239] 
Daohui Rongp [dr766] 
Anish Grover [ag1367] 
Tejas Rajput [tr369]  

Files:
Dataset.csv : main dataset file for training the model
Main.ipynb  : Jupyter notebook with the entire project code
TwitClean.py and TwitCrawl.py : python files for collecting URLs from tweets of seed Twitter user.

To run the project, Please run the Main file using Jupyter Notebook !